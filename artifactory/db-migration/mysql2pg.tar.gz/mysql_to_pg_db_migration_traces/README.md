This is mandatory directory for traces of DB migration process
